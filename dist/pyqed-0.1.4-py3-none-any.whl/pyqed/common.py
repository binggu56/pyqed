def dagger(H):
    return H.conj().T

def delta(n, m):
    return float(n==m)
